classdef OffOnEnum < Simulink.IntEnumType
	enumeration
		OOE_Off(0), 
		OOE_On(1)
	end
end
