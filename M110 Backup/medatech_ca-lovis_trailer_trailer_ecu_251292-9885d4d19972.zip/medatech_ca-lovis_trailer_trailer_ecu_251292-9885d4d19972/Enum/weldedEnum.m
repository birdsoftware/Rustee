classdef weldedEnum < Simulink.IntEnumType
	enumeration
		welded_False(0), 
		welded_True(1), 
	end
end