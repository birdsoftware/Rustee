classdef Trac_InverterMainState < Simulink.IntEnumType
    
enumeration
    Trac_Unknown(0),
    Trac_Startup(1),
    Trac_MainsCheck(2),
    Trac_MainsOK(3),
    Trac_Precharge(4),
    Trac_PreChargDone(5),
    Trac_PowerReady(6),
    Trac_Alarmed(7),
    Trac_PowerReadyDirectReq(8),
    Trac_PowerReadyExtPreChargReq(9)
  end

  methods (Static)
    function retVal = getDefaultValue()
      retVal = Trac_InverterMainState.Trac_Unknown;
    end
    function retVal = addClassNameToEnumNames()
        retVal = false;  
    end       
  end  
end
