classdef Trac_InverterMainStateRequest < Simulink.IntEnumType
    
enumeration
    TR_Unknown(0),
    TR_Startup(1),
    TR_MainsCheck(2),
    TR_MainsOK(3),
    TR_Precharge(4),
    TR_PreChargDone(5),
    TR_PowerReady(6),
    TR_Alarm(7),
    TR_PowerReadyDirectReq(8),
    TR_PowerReadyExtPreChargReq(9)
  end

  methods (Static)
    function retVal = getDefaultValue()
      retVal = Trac_InverterMainStateRequest.TR_Unknown;
    end
    function retVal = addClassNameToEnumNames()
        retVal = false;  
    end       
  end  
end
