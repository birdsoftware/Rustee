classdef FalseTrueEnum < Simulink.IntEnumType
    
enumeration
    FTE_False(0),
    FTE_True(1)
  end
    
  methods (Static)
    function retVal = getDefaultValue()
      retVal = FalseTrueEnum.FTE_False;
    end
    function retVal = addClassNameToEnumNames()
        retVal = false;  
    end       
  end  
end