classdef truckCANerrorEnum < Simulink.IntEnumType
	enumeration
		truck_commsfailure_False(0), 
		truck_commsfailure_True(1), 
	end
end