classdef generator_runningEnum < Simulink.IntEnumType
	enumeration
		generator_off(0), 
		generator_running(1), 
	end
end