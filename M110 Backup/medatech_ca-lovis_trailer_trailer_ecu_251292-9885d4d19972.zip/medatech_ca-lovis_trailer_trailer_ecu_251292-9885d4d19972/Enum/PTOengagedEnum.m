classdef PTOengagedEnum < Simulink.IntEnumType
	enumeration
		PTO_disengaged(0), 
		PTO_engaged(1), 
	end
end