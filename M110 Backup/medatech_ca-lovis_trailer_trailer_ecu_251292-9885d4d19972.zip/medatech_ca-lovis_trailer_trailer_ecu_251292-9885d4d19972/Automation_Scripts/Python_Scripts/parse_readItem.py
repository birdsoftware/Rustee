#!/usr/bin/env python
# coding: utf-8

# # Parse TM4 Item Configuration

# In[1]:


import pandas as pd
import numpy as np
import sys


# ### 1. Read in raw data

# In[2]:


txt_path = sys.argv[1]+r'TM4_Export\readItem_export.txt'
raw_data = pd.read_csv(txt_path, sep='\n', names=["raw_value"]).iloc[1:,:]


# ### 2. Parse data

# In[3]:


raw_data["raw_value"] = raw_data.raw_value.str.split("|")


# In[4]:


header_list = ["Tree_Path", "Item_Name", "Type", "Enum_Name", "Size_M", "Size_N", "Min", "Max", "Default_Value", "Units", "Description", "Iq", "Gain", "Offset", "Readable", "Writable", "Used"]


# In[5]:


result = pd.DataFrame(data=None, index=header_list).T


# In[6]:


for rows in range(0,raw_data.shape[0]):
    result2 = pd.DataFrame(data=raw_data.iloc[rows][0], index=header_list).T
    result = result.append(result2, ignore_index=True)
result = result.replace('Inf',"")
result = result.replace('-Inf',"")


# ### 3. Export result to CSV

# In[7]:


csv_path = sys.argv[1]+r'Python_Scripts\readItem_parsed.csv'
result.to_csv(csv_path, index=False)


# In[ ]:




