function cleanUp(prjFolder)

% start error log
project_folder = prjFolder;
error_log = fopen(strcat(project_folder, 'Automation_Scripts\error_log.txt'),'w');

% delete TM4 Title block and add OpenECU title block
try
    oriPos = get_param(find_system(bdroot,'SearchDepth',1,'MaskType','TM4 J1939 Configuration'),'Position');
    oriPos = oriPos{1};
    oriPos = [oriPos(1) oriPos(2) oriPos(1) oriPos(2)];

    delete_block(find_system(bdroot,'SearchDepth',1,'regexp', 'on','MaskType','TM4.'));
    delete_block(find_system(bdroot,'SearchDepth',1,'regexp', 'on','Name','TM4.'));
    delete_block(find_system(bdroot,'SearchDepth',1,'regexp', 'on','Name','Data Store Memory'));
    delete(find_system(bdroot,'FindAll','on','type','annotation','Parent',bdroot));

    add_block('plat_lib/Target Identification and Configuration/Identification/put_Identification',...
        [bdroot '/put_Identification'],'Position',oriPos + [0 -200 320 30]);
    add_block('plat_lib/Communication Drivers/CAN Drivers/pcx_CANConfiguration',...
        [bdroot '/pcx_CANConfiguration1'],'Position',oriPos + [330 -200 500 -130]);
    add_block('plat_lib/Communication Drivers/CAN Drivers/pcx_CANConfiguration',...
        [bdroot '/pcx_CANConfiguration2'],'Position',oriPos + [330 -120 500 -50]);
    add_block('plat_lib/Communication Drivers/CAN Drivers/pcx_CANConfiguration',...
        [bdroot '/pcx_CANConfiguration3'],'Position',oriPos + [330 -40 500 30]);
    add_block('plat_lib/Communication Drivers/CCP Drivers/pcp_CCPConfiguration',...
        [bdroot '/pcp_CCPConfiguration'],'Position',oriPos + [510 -200 700 -100]);
    add_block('plat_lib/Target Identification and Configuration/Memory Allocation/pmem_MemoryConfiguration',...
        [bdroot '/pmem_MemoryConfiguration'],'Position',oriPos + [510 -90 700 -20]);
    add_block('Medatech_Lib/Configure Secondary Micro',[bdroot '/Configure Secondary Micro'],...
        'Position',oriPos + [510 -10 700 30], 'ShowName','off');
    add_block('plat_lib/RealTime Workshop Utilities/prtw_ConfigUsingRtwEc',...
        [bdroot '/prtw_ConfigUsingRtwEc'],'Position',oriPos + [710 -200 850 -130]);
    add_block('Medatech_Lib/save_static_param',[bdroot '/save_static_param'],...
        'Position',oriPos + [510 40 700 80], 'ShowName','off');
catch ME
    appPrint('Error replacing title blocks');
    fprintf(error_log,'Error replacing title blocks');
    fprintf(error_log,'\n');
    fprintf(error_log, [ME.message,'\n']);
end

try
    % search for tm4 library block and delete
    tbdBlocks = find_system(find_system(bdroot,'regexp', 'on','MaskType','TM4.'));
    delete_block(tbdBlocks);
    % delete empty connections
    emptyLines = find_system(bdroot,'findall','on','type','line','connected','off');
    delete(emptyLines);
    % terminate empty ports
    emptyInports = find_system(bdroot,'findall','on','type','port','Line',-1,'PortType','inport');
    emptyOutports = find_system(bdroot,'findall','on','type','port','Line',-1,'PortType','outport');
         % inports
    for i = 1:length(emptyInports)
        try
            currentSys = get_param(get_param(emptyInports(i),'Parent'),'parent');
            portPos = get_param(emptyInports(i),'Position');
            newPortName = [currentSys '/gnd' num2str(i)];
            add_block('simulink/Sources/Ground',newPortName,...
                'Position',[portPos(1)-25 portPos(2)-10 portPos(1)-5 portPos(2)+10],...
                'ShowName', 'off');
            newPortHandles = get_param(newPortName,'PortHandles');
            newOutport = newPortHandles.Outport(1);
            add_line(currentSys,newOutport,emptyInports(i));
        catch MEIP
            appPrint('Error cleaning up empty Inports');
            fprintf(error_log,'Error cleaning up inport: ');
            fprintf(error_log,get_param(emptyInports(i),'Parent'));
            fprintf(error_log,'\n');
            fprintf(error_log, [MEIP.message,'\n']);
        end
    end
        % outports
    for i = 1:length(emptyOutports)
        try
            currentSys = get_param(get_param(emptyOutports(i),'Parent'),'parent');
            portPos = get_param(emptyOutports(i),'Position');
            newPortName = [currentSys '/ter' num2str(i)];
            add_block('simulink/Sinks/Terminator',newPortName,...
                'Position',[portPos(1)+5 portPos(2)-10 portPos(1)+25 portPos(2)+10],...
                'ShowName', 'off');
            newPortHandles = get_param(newPortName,'PortHandles');
            newInport = newPortHandles.Inport(1);
            add_line(currentSys,emptyOutports(i),newInport);
        catch MEOP
            appPrint('Error cleaning up empty Outports');
            fprintf(error_log,'Error cleaning up outport: ');
            fprintf(error_log,get_param(emptyOutports(i),'Parent'));
            fprintf(error_log,'\n');
            fprintf(error_log, [MEOP.message,'\n']);
        end
    end
catch ME
    appPrint('Error cleaning up empty ports and lines');
    fprintf(error_log,'Error cleaning up empty ports and lines');
    fprintf(error_log,'\n');
    fprintf(error_log, [ME.message,'\n']);
end

fclose(error_log);

end

