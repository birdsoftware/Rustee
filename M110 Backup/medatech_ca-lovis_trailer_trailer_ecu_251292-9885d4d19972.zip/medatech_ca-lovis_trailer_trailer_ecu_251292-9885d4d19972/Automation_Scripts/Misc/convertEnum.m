function convertedTable = convertEnum(originalTable)
%%% This function converts enums in table imported from csv to proper
%%% format

if any(strcmp('Default_Value',originalTable.Properties.VariableNames))
    originalTable = convertvars(originalTable,{'Default_Value'},'string');
end

dType = originalTable.('Type');
for row_num = 1:length(dType)
   if contains(dType(row_num),'Enum')
       if ~strcmp(dType{row_num},'Enum: ->')
           originalTable.('Enum_Name')(row_num) = dType(row_num);
           originalTable.('Type'){row_num} = 'Enum: ->';
       end
       if any(strcmp('Default_Value',originalTable.Properties.VariableNames))
           [~,enumEntry] = enumeration(originalTable.('Enum_Name'){row_num});
           defaultValue = originalTable.('Default_Value')(row_num);
           originalTable.('Default_Value')(row_num) = ...
            [originalTable.('Enum_Name'){row_num} '.' enumEntry{str2double(defaultValue)+1}];
       end
   end
end

convertedTable = originalTable;

end

