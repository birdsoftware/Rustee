function className = enumClass(var)
%%% This function returns Enum class name of input var

if ~Simulink.data.existsInGlobal(bdroot,var) % variable does not exist
    className = 'NA';
else
    try
        % obtain data type from data dictionary
        masterDictObj = Simulink.data.dictionary.open('masterDict.sldd'); 
        dDataSectObj = getSection(masterDictObj,'Design Data');
        entry = getEntry(dDataSectObj,var);
        entry_value = getValue(entry);
        dtype = entry_value.DataType;

        className = dtype;
    catch
        className = 'Error';
    end
end

end

