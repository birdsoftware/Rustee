% Remove DM1 blocks
load_system('simulink');
dm1List = find_system(bdroot,'MaskType','J1939 SysFile Event With DM1 and DM2');
% dm1List = find_system(bdroot,'MaskType','TM4 SysFile Event');
for i = 1:length(dm1List)
    current_block = dm1List{i};
    current_system = get_param(current_block,'Parent');
    lh = get_param(current_block,'lineHandles');
    srcPort = get_param(lh.Trigger,'SrcPortHandle');
    delete_line(lh.Trigger);
    delete_line(lh.Inport);
    replace_block(current_block,'J1939 SysFile Event With DM1 and DM2','simulink/Sinks/Terminator','noprompt')
    dstPh = get_param(gcb,'portHandles');
    add_line(current_system,srcPort,dstPh.Inport);
end