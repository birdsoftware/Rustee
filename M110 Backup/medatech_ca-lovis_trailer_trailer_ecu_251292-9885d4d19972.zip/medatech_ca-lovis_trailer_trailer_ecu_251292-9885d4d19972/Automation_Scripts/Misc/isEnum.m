function result = isEnum(var)
%%% This function returns True is var is of dtype Enum, else False

if ~Simulink.data.existsInGlobal(bdroot,var) % variable does not exist
    result = -1;
else
    try
        % obtain data type from data dictionary
        masterDictObj = Simulink.data.dictionary.open('masterDict.sldd'); 
        dDataSectObj = getSection(masterDictObj,'Design Data');
        entry = getEntry(dDataSectObj,var);
        entry_value = getValue(entry);
        dtype = entry_value.DataType;

        if contains(dtype,'Enum')
            result = 1;
        else
            result = 0;
        end
    catch
        result = -2;
    end
end

end

