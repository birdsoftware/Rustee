function Main(prjFolder,prjFile)
    % define variables
baseVarList = evalin('base', 'who');    % get base workspace variables
app = get(findall(0, 'Name', 'VMU Porting Tool'), 'RunningAppInstance'); % get the UI instance

project_folder = prjFolder;
project_name = prjFile;

% initialization
    % init file paths
project_file = strcat(project_folder, project_name);
scripts_path = strcat(project_folder, 'Automation_Scripts\');
load_system(project_file);
    % init error log
error_log = fopen(strcat(project_folder, 'Automation_Scripts\error_log.txt'),'w');
fprintf(error_log, ['\n\n','---------------------- ', datestr(datetime('now')), ' -----------------------','\n']);
    % init flag
error_flag = false;

% create master data dictionary and link to model
appPrint(app.TextArea,'Program Started');
Simulink.data.dictionary.create(strcat(scripts_path, 'Data_Dict\masterDict.sldd'));
masterDictObj = Simulink.data.dictionary.open('masterDict.sldd'); 
dDataSectObj = getSection(masterDictObj,'Design Data');
load_system(project_file);
set_param(gcs,'DataDictionary','masterDict.sldd');  % link to Simulink model
% update data type conversions variables
updateDataType;
% copy base workspace variables to master dd
for i=1:length(baseVarList)
    addEntry(dDataSectObj,baseVarList{i},evalin('base', baseVarList{i}));
end
% add save_checksum variable to master dd
saveParam = Simulink.Parameter;
saveParam.DataType = 'boolean';
saveParam.Value = 0;
saveParam.Min = 0;
saveParam.Max = 1;
saveParam.StorageClass = "Volatile";
addEntry(dDataSectObj,'savec_checksum',saveParam);

%%% ---------------------- MAIN PROCESS ------------------------ %%%
% Static Parameter
if isfile(strcat(scripts_path,'TM4_Export\staParam_export.txt'))
    appPrint(app.TextArea,'Migrating static parameters...');
    staParamMigration;
    appPrint(app.TextArea,'...Static parameter migration finished');
end
% Dynamic Parmeter
if isfile(strcat(scripts_path,'TM4_Export\dynParam_export.txt'))
    appPrint(app.TextArea,'Migrating dynamic parameters...');
    dynParamMigration;
    appPrint(app.TextArea,'...Dynamic parameter migration finished');
end
% Read Items
if isfile(strcat(scripts_path,'TM4_Export\readItem_export.txt'))
    appPrint(app.TextArea,'Migrating read items...');
    readItemMigration;
    appPrint(app.TextArea,'...Read item migration finished');
end
% Write Items
if isfile(strcat(scripts_path,'TM4_Export\writeItem_export.txt'))
    appPrint(app.TextArea,'Migrating write items...');
    writeItemMigration;
    appPrint(app.TextArea,'...Write item migration finished');
end
% % CAN Rx
% appPrint(app.TextArea,'Migrating J1939 CAN Rx...');
% error_flag = canRxUpdate(error_log)||error_flag;
% appPrint(app.TextArea,'...J1939 CAN Rx migration finished');
% CAN Tx
appPrint(app.TextArea,'Migrating CAN Tx...');
error_flag = canTxUpdate(error_log)||error_flag;
appPrint(app.TextArea,'...CAN Tx migration finished');
%IO
appPrint(app.TextArea,'Migrating IO...');
error_flag = migrateIO(app,error_log)||error_flag;
appPrint(app.TextArea,'...IO migration finished');

% end of process
if error_flag == true
    appPrint(app.TextArea,'------- Finished with error, check error log -------');
else
    appPrint(app.TextArea,'------- Migration successful -------');
end
fclose(error_log);


end

