function log_table_size = updateLog(spn,time)

global test_log_table
log_table_size =  size(test_log_table,1);


end

