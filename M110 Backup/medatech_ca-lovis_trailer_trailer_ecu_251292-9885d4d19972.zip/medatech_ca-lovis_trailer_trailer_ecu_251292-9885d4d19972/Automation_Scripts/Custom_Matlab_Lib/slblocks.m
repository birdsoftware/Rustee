function blkStruct = slblocks
    Browser.Library = 'Medatech_Lib';
    Browser.Name = 'Medatech Library';
    blkStruct.Browser = Browser;