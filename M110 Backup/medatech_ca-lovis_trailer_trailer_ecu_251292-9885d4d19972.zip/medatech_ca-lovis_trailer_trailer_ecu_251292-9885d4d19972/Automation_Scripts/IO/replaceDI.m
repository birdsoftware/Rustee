function err_flag = replaceDI(table,error_log)

err_flag = false;
diBlocks = find_system(bdroot,'MaskType','TM4 Digital Input');
diBlocks = string(diBlocks);

for i = 1:length(diBlocks)
    try
        sampleTime = get_param(diBlocks(i),'InputSampleTime');
        TM4_chan = get_param(diBlocks(i),'InputChannel');
        OE_chan = table.OE_cnames(ismember(table.TM4_cnames,TM4_chan));
        
        if ismissing(OE_chan)
            err_flag = true;
            fprintf(error_log, 'Target OE IO channel not defined: ');
            fprintf(error_log,string(diBlocks(i)));
            fprintf(error_log, '\n');
        elseif OE_chan=="NA"
            delete_block(diBlocks(i));
        else
            replace_block(diBlocks(i),'TM4 Digital Input','plat_lib/Input Drivers/pdx_DigitalInput','noprompt');
            set_param(diBlocks(i),'pdxl_provide_sim_input','off','pdxl_di_sample',sampleTime,...
                'chan',string(OE_chan), 'pdxl_di_setdeadtime','0','pdxl_di_resetdeadtime','0');
        end
    catch ME
        err_flag = true;
        fprintf(error_log, 'Error replacing DI block: ');
        fprintf(error_log, string(diBlocks(i)));
        fprintf(error_log, '\n');
        fprintf(error_log, [ME.message, '\n']);
    end
end

end

