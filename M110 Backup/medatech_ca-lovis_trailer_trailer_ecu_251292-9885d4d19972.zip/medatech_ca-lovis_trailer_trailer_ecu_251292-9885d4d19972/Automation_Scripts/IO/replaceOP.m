function err_flag = replaceOP(table,error_log)
err_flag = false;
opBlocks = find_system(bdroot,'regexp','on','MaskType','TM4+(\w|\s)+Output$');
opBlocks = string(opBlocks);

for i = 1:length(opBlocks)
    try
        TM4_chan = get_param(opBlocks(i),'OutputChannel');
        OE_chan = table.OE_cnames(ismember(table.TM4_cnames,TM4_chan));
        
        if ismissing(OE_chan)
            err_flag = true;
            fprintf(error_log, 'Target OE IO channel not defined: ');
            fprintf(error_log,string(opBlocks(i)));
            fprintf(error_log, '\n');
        elseif OE_chan=="NA"
            delete_block(opBlocks(i));
        else
            replace_block(opBlocks(i),get_param(opBlocks(i),'MaskType'),...
                'Medatech_Lib/OpenECU IO Output','noprompt');
            set_param(opBlocks(i),'channel',string(OE_chan));
%             replace_block(opBlocks(i),get_param(opBlocks(i),'MaskType'),...
%                 'plat_lib/Output Drivers/pdx_DigitalOutput','noprompt');
%             set_param(opBlocks(i),'pdxl_provide_sim_output','off','pdxl_do_default','0',...
%                 'chan',string(OE_chan));
        end
    catch ME
        err_flag = true;
        fprintf(error_log, 'Error replacing OP block: ');
        fprintf(error_log, string(opBlocks(i)));
        fprintf(error_log, '\n');
        fprintf(error_log, [ME.message, '\n']);
    end
end


end

