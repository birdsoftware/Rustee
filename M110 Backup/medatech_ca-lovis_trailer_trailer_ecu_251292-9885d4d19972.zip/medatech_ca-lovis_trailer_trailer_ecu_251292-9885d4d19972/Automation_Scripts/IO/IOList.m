function [IOList,IOPorts] = IOList(modelPath, blockType)

load_system(modelPath);
IOList = find_system(modelPath,'regexp','on','MaskType',blockType);
IOPorts = cell(length(IOList),1);
if contains(blockType,'Input')
    for i = 1:length(IOList)
        channel = get_param(IOList(i),'InputChannel');
        IOPorts{i} = channel{1};
    end
else
    for i = 1:length(IOList)
        channel = get_param(IOList(i),'OutputChannel');
        IOPorts{i} = channel{1};
    end
end
IOPorts = unique(IOPorts);

end

