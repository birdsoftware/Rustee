function err_flag = replaceAI(table,error_log)
err_flag = false;
aiBlocks = find_system(bdroot,'MaskType','TM4 Analog Input');
aiBlocks = string(aiBlocks);

for i = 1:length(aiBlocks)
    try
        sampleTime = get_param(aiBlocks(i),'InputSampleTime');
        TM4_chan = get_param(aiBlocks(i),'InputChannel');
        OE_chan = table.OE_cnames(ismember(table.TM4_cnames,TM4_chan));
        
        if ismissing(OE_chan)
            err_flag = true;
            fprintf(error_log, 'Target OE IO channel not defined: ');
            fprintf(error_log,string(aiBlocks(i)));
            fprintf(error_log, '\n');
        elseif OE_chan=="NA"
            delete_block(aiBlocks(i));
        else
            replace_block(aiBlocks(i),'TM4 Analog Input','plat_lib/Input Drivers/pai_BasicAnalogInput','noprompt');
            set_param(aiBlocks(i),'pail_provide_sim_input','off','pail_sample',sampleTime,...
                'chan',string(OE_chan));
        end
    catch ME
        err_flag = true;
        fprintf(error_log, 'Error replacing AI block: ');
        fprintf(error_log, string(aiBlocks(i)));
        fprintf(error_log, '\n');
        fprintf(error_log, [ME.message, '\n']);
    end
end

end

