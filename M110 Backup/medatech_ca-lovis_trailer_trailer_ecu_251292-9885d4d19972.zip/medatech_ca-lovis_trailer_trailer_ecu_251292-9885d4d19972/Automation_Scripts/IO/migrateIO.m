function err_flag = migrateIO(app,error_log)

err_flag = false;
% AI
try
    AITable = app.AIUITable.Data;
    err_flag = replaceAI(AITable,error_log)||err_flag;
catch ME
    err_flag = true;
    fprintf(error_log,'Error configuring Analog Input ');
    fprintf(error_log,'\n');
    fprintf(error_log, [ME.message,'\n']);
end
% DI
try
    DITable = app.DIUITable.Data;
    err_flag = replaceDI(DITable,error_log)||err_flag;
catch ME
    err_flag = true;
    fprintf(error_log,'Error configuring Digital Input ');
    fprintf(error_log,'\n');
    fprintf(error_log, [ME.message,'\n']);
end
% OP
try
    OPTable = app.OPUITable.Data;
    err_flag = replaceOP(OPTable,error_log)||err_flag;
catch ME
    err_flag = true;
    fprintf(error_log,'Error configuring Digital Output ');
    fprintf(error_log,'\n');
    fprintf(error_log, [ME.message,'\n']);
end

end

