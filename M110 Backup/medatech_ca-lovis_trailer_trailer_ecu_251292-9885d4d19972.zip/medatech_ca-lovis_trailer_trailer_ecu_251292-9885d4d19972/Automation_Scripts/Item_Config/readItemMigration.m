%%%------------ CREATE DATA DICTIONARY FROM TM4 ITEM CONFIG EXPORT ------------- %%%
% parse txt and save as csv
py_cmd = strcat('python'," ",scripts_path,'Python_Scripts\parse_readItem.py'," ",scripts_path);
py_exet_st = system(py_cmd);

% read from parsed csv
readItem_table = readtable(strcat(scripts_path,'Python_Scripts\readItem_parsed.csv'));
readItem_table = convertEnum(readItem_table);

% % create and get section of the readItem data dictionary
Simulink.data.dictionary.create(strcat(scripts_path, 'Data_Dict\readItemDict.sldd'));
readItemDictObj = Simulink.data.dictionary.open('readItemDict.sldd');
dDataSectObj = getSection(readItemDictObj,'Design Data');
% loop through all rows
for row_num = 1:height(readItem_table)
    % create new Simulink parameters
    newParam = Simulink.Parameter;
        % use enumeration class if value is enumeration
    if isempty(readItem_table.Enum_Name{row_num})
        newParam.DataType = readItem_table.Type{row_num};
        newParam.Value = str2double(readItem_table.Default_Value{row_num});
    else
        enum = split(readItem_table.Default_Value{10},'.');
        enum_class = enumeration(enum{1});
        newParam.DataType = ['Enum: ' enum{1}];
        newParam.Value = enum_class(enum{2}==enum_class);
    end
    newParam.Description = readItem_table.Description{row_num};
        % use empty value if unit is "-"
    if readItem_table.Units{row_num}~="-"
        newParam.Unit = readItem_table.Units{row_num};
    end
    % storage class
    newParam.StorageClass = "Volatile";
    % write to data dictionary
    addEntry(dDataSectObj,readItem_table.Item_Name{row_num},newParam);
end
% save changes
saveChanges(readItemDictObj);
addDataSource(masterDictObj,'readItemDict.sldd');   % reference readItem to master DD
saveChanges(masterDictObj);

%%%------------ REPLACE EXISTING READ BLOCK WITH VALUE IN DATA DICTIONARY -------------%%%
load_system('Medatech_Lib') % load custom library
load_system(project_file)
% get the list of path of all block to be replaced
oldBlockList = find_system(gcs,'MaskType','TM4 Read Item');
% loop through all items to be replaced
for item = 1:length(oldBlockList)
    % get reference object name
    ddName = get_param(oldBlockList{item},'ItemName'); % get reference variable name
    sampleTime = get_param(oldBlockList{item},'sampleTime'); % get sample time
    opEnum = get_param(oldBlockList{item},'OutputEnumType');
    % replace the old block with new block referencing to object name
    currentPath = oldBlockList{item};   % path to the current block
    try
%         replace_block(currentPath,'TM4 Read Item','Constant','noprompt');  % replace TM4 block with OpenECU block
%         set_param(gcb,'Value',ddName);  % set new block value to corresponding dd value
%         set_param(gcb,'SampleTime',sampleTime); % set new block sample time to corresponding value
        replace_block(oldBlockList{item},'TM4 Read Item','Medatech_Lib/OpenECU Read Item','noprompt');
        set_param(oldBlockList{item},'dd_variable',ddName);
        set_param(oldBlockList{item},'output_enum',opEnum);
    catch ME
        % log error
        error_flag = true;
        fprintf(error_log, [ME.message,'\n']);
    end
end


