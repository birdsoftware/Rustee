%%%------------ CREATE DATA DICTIONARY FROM TM4 ITEM CONFIG EXPORT ------------- %%%
% parse txt and save as csv
py_cmd = strcat('python'," ",scripts_path,'Python_Scripts\parse_writeItem.py'," ",scripts_path);
py_exet_st = system(py_cmd);

% read from parsed csv
writeItem_table = readtable(strcat(scripts_path,'Python_Scripts\writeItem_parsed.csv'));
writeItem_table = convertEnum(writeItem_table);

% create and get section of the writeItem data dictionary
Simulink.data.dictionary.create(strcat(scripts_path, 'Data_Dict\writeItemDict.sldd'));
writeItemDictObj = Simulink.data.dictionary.open('writeItemDict.sldd');
dDataSectObj = getSection(writeItemDictObj,'Design Data');
% loop through all rows
for row_num = 1:height(writeItem_table)
    % create new Simulink parameters
    newParam = Simulink.Signal;
        % use enumeration class if value is enumeration
    if isempty(writeItem_table.Enum_Name{row_num})
        newParam.DataType = writeItem_table.Type{row_num};
    else
        newParam.DataType = ['Enum: ' writeItem_table.Enum_Name{row_num}];
    end
    newParam.Description = writeItem_table.Description{row_num};
        % use empty value if unit is "-"
    if writeItem_table.Units{row_num}~="-"
        newParam.Unit = writeItem_table.Units{row_num};
    end
    % storage class
    newParam.StorageClass = "Volatile";
    % write to data dictionary
    addEntry(dDataSectObj,['m_' writeItem_table.Item_Name{row_num}],newParam);
end
% save changes
saveChanges(writeItemDictObj);
addDataSource(masterDictObj,'writeItemDict.sldd');   % reference writeItem to master DD
saveChanges(masterDictObj);

%%%------------ REPLACE EXISTING WRITE BLOCK WITH VALUE IN DATA DICTIONARY -------------%%%
load_system('Medatech_Lib'); % load custom library
load_system(project_file);
% get the list of path of all block to be replaced
oldBlockList = find_system(gcs,'MaskType','TM4 Write Item');
% loop through all items to be replaced
for item = 1:length(oldBlockList)
    % get reference object name
    ddName = get_param(oldBlockList{item},'ItemName'); % get reference variable name
    showOp = get_param(oldBlockList{item},'ShowOutput');   % get number of outport
    input_enum = get_param(oldBlockList{item},'InputEnumType');
    output_enum = get_param(oldBlockList{item},'OutputEnumType');
    % replace the old block with new block referencing to object name
    currentPath = oldBlockList{item};   % path to the current block
    try
        replace_block(currentPath,'TM4 Write Item','Medatech_Lib/OpenECU Write Item','noprompt');  % replace TM4 block with OpenECU block
        set_param(gcb,'dd_variable',['m_' ddName]);  % set new block value to corresponding dd value
        set_param(gcb,'showop',showOp);
        set_param(gcb,'input_enum',input_enum);
        set_param(gcb,'output_enum',output_enum);
    catch ME
        % log error
        error_flag = true;
        fprintf(error_log, [ME.message,'\n']);
    end
end
