function replaceTxBlock(J1939, blockPath)
blockPath = blockPath{1};
% ------ get information from TM4 CAN Pack block
if J1939==1 % J1939
    old_block = find_system(blockPath,'MaskType','TM4 J1939 CAN Pack');
elseif J1939==2 % general CAN
    old_block = find_system(blockPath,'MaskType','TM4 CAN Pack');
end
userData = get_param(old_block, 'UserData');
CanDbFile = userData{1,1}.CanDbFile;
MsgName = userData{1,1}.MsgName;
SigTable = userData{1,1}.MsgSignalTable;
SigTableSize = size(SigTable);
SigList = "";
for row_num = 1:SigTableSize(1)
    SigList = SigList + convertCharsToStrings(SigTable{row_num,1});
    if row_num ~= SigTableSize(1)
        SigList = SigList + ",";
    end
end

% ------ Replace block with OpenECU block
% get list of original Inport names
load_system('Medatech_Lib');
load_system(blockPath);

lh = get_param(blockPath,'lineHandles');
numInport = length(lh.Inport);
srcPortList = ones(numInport);
for i = 1:numInport
    srcPortList(i) = get_param(lh.Inport(i),'SrcPortHandle');
    delete_line(lh.Inport(i));
end

% replace TM4 block with OpenECU block
originPos = get_param(blockPath,'Position');
if J1939==1 % J1939
    replace_block(blockPath,'TM4 J1939 CAN Pack', 'Medatech_Lib/OpenECU CAN Transmit','noprompt');
elseif J1939==2 % general CAN
    replace_block(blockPath,'TM4 CAN Pack', 'Medatech_Lib/OpenECU CAN Transmit','noprompt');
end
set_param(blockPath,'candb_file',CanDbFile);
set_param(blockPath,'msg_name',MsgName);
set_param(blockPath,'signal_name',SigList);
set_param(blockPath,'Position',originPos);
% reconnect new OpenECU block to inports
dividers = strfind(blockPath,'/');
lastDivider = dividers(length(dividers));
currentSys = blockPath(1:lastDivider);
currentPH = get_param(blockPath,'portHandles');
for i = 1:numInport
     add_line(currentSys, srcPortList(i), currentPH.Inport(i));
end

end

