function replaceCAN(blockPath,oldBlocktype,newBlockType,canDbFile,canMsg,canSigList)
%{
Replace TM4 CAN Rx&Tx block with OpenECU CAN block and set parameters
%}

originPos = get_param(blockPath,'Position');
replace_block(blockPath,oldBlocktype, newBlockType,'noprompt');
set_param(blockPath,'candb_file',canDbFile);
set_param(blockPath,'msg_name',canMsg);
set_param(blockPath,'signal_name',canSigList{1});
set_param(blockPath,'Position',originPos);
end

