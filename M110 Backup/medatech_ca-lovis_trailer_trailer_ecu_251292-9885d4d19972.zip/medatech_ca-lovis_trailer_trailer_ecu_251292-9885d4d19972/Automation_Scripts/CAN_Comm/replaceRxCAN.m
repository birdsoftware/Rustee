function replaceRxCAN(blockPath)
% trace to unpack block
rxBlkPath = find_system(blockPath,'MaskType','TM4 Receive CAN Message');
rxBlkPath = rxBlkPath{1};
mailbox = get_param(rxBlkPath,"Parent");
MBconnectivity = get_param(mailbox,'PortConnectivity');
cntTable = struct2table(MBconnectivity);
unpackSys = cntTable.DstBlock(2);
unpackSysPath = getfullname(unpackSys);
unpackBlk = find_system(unpackSysPath,'MaskType','TM4 CAN Unpack');

% initialize rx block state
rxBlkFinished = 0;

% obtain parameters from unpack block
upUserData = get_param(unpackBlk,'userData');
CanDbFile = upUserData{1,1}.CanDbFile;
MsgName = upUserData{1,1}.MsgName;
upSigTable = upUserData{1,1}.MsgSignalTable;
SigList = "";
for row_num = 1:size(upSigTable,1)
    SigList = SigList + convertCharsToStrings(upSigTable{row_num,1});
    if row_num ~= size(upSigTable,1)
        SigList = SigList + ",";
    end
end

% replace TM4 block with OpenECU block
[rxTargetName,rxTargetType,rxTargetPath] = cntedBlockInfo(rxBlkPath,'Outport',3);
removeLine(rxBlkPath,'Outport','start','end');
replaceCAN(rxBlkPath,'TM4 Receive CAN Message', 'Medatech_Lib/OpenECU CAN Receive',...
                CanDbFile, MsgName, SigList);
% save parameters for later
rxBlkPort = get_param(rxBlkPath,'PortHandles');
numOutput = length(rxBlkPort.Outport);
[~,~,newMsgDst] = cntedBlockInfo(mailbox,'Outport',1);

% if output is connected to outport
if rxTargetType == "Outport"
    % remove mailbox out connections
    removeLine(mailbox,'Outport','start','end');
    % add new outports
    oriPos = get_param(rxBlkPath,'Position');
    set_param(rxBlkPath,'Position',[oriPos(1)-200,oriPos(2)-25*numOutput,oriPos(3),oriPos(4)]);
    Outport = find_system(mailbox,'blockType','Outport');
    terminator = find_system(mailbox,'blockType','Terminator');
    delete_block(terminator);
    for i = 1:size(Outport,1)
        delete_block(Outport(i));
    end
    for i = 1:numOutput
        add_block('simulink/Quick Insert/Ports & Subsystems/Outport',...
            convertCharsToStrings(mailbox)+'/Outport'+i, 'IconDisplay', 'Signal name');
        outputPos = get_param(rxBlkPort.Outport(i),'Position');
        set_param(gcb,'Position', [outputPos(1)+100,outputPos(2)-7,outputPos(1)+130,outputPos(2)+7]);
    end
    % connect to new outports
    Outport = find_system(mailbox,'blockType','Outport');
    for i = 1:numOutput
        add_line(mailbox,convertCharsToStrings(get_param(rxBlkPath,'Name'))+'/'+i,...
            convertCharsToStrings(get_param(Outport(i),'Name'))+'/1');
    end
    % set connection names
    lh = get_param(rxBlkPath,'LineHandles');
    set_param(lh.Outport(1),'Name','NewMessage');
    for i=2:numOutput
        set_param(lh.Outport(i),'Name',upSigTable{i-1,1});
    end
    rxBlkFinished = 1;
% if output is connected to bus creator
elseif rxTargetType == "BusCreator"
    % remove rx block connections
    removeLine(rxBlkPath,'Outport','start','end');
    % edit bus collectors
    set_param(rxTargetPath,'Inputs',num2str(size(upSigTable,1)+1));
    % connect new blocks to new bus collectors
    for i = 1:size(upSigTable,1)+1
        add_line(mailbox,convertCharsToStrings(get_param(rxBlkPath,'name'))+'/'+i,...
            convertCharsToStrings(rxTargetName)+'/'+i);
    end
    % set line name
    setLineParam(rxBlkPath,'Outport',1,'name','NewMessage');
    for i = 2:size(upSigTable,1)+1
        setLineParam(rxBlkPath,'Outport',i,'name',upSigTable{i-1,1});
    end
    % edit outport bus selector
        % only edit outport when all receive block have been replaced
    if isempty(find_system(mailbox,'MaskType','TM4 Receive CAN Message'))==1
        % remove mailbox out connections
        removeLine(mailbox,'Outport','start','end');
        % edit bus selectors
        busSelector = find_system(mailbox,'blockType','BusSelector');
        removeLine(busSelector{1},'Outport','start','end');
        busIp = get_param(busSelector,'InputSignals');
        set_param(busSelector{1},'OutputSignals',convertStringsToChars(strjoin(busIp{1},', ')));
        % add new outports
        outports = find_system(mailbox,'blockType','Outport');
        for i = 1:size(outports,1)
            delete_block(outports{i});
        end
        for i = 1:size(upSigTable,1)+1
            add_block('simulink/Quick Insert/Ports & Subsystems/Outport',...
                    convertCharsToStrings(mailbox)+'/Outport'+i, 'IconDisplay', 'Signal name');
        end
        % set new outport positions
        ph = get_param(busSelector,'portHandles');
        busSelPortPos = ph{1}.Outport;
        newOp = find_system(mailbox,'blockType','Outport');
        for i = 1:numel(newOp)
           pos = get_param(busSelPortPos(i),'Position');
           set_param(newOp{i},'Position', [pos(1)+100,pos(2)-7,pos(1)+130,pos(2)+7]); 
        end
        % connect to new outports
        for i = 1:numel(newOp)
            add_line(mailbox,convertCharsToStrings(get_param(busSelector,'name'))+'/'+i,...
                convertCharsToStrings(get_param(newOp{i},'name'))+'/1');
        end
        % connect CAN Rx block to Logical Operator
        loBlock = find_system(mailbox,'blockType','Logic');
        add_line(mailbox,convertCharsToStrings(get_param(rxBlkPath,'name'))+'/1',...
            convertCharsToStrings(get_param(loBlock,'name'))+'/1');
        rxBlkFinished = 1;
    end
end

%%% -------------- modify unpack system & block -----------------%%%
if rxBlkFinished==1 % only modify unpack system when rx block is finished
    % add inport to unpack system
        % remove old inports
    removeLine(unpackBlk{1},'Inport','start','end');
    inport = find_system(unpackSysPath,'blockType','Inport');
    for i = 1:size(inport,1)
       delete_block(inport(i));
    end
        % add new inports
    for i = 1:numOutput-1
        add_block('simulink/Quick Insert/Ports & Subsystems/Inport',...
            convertCharsToStrings(unpackSysPath)+'/Inport'+i, 'IconDisplay', 'Signal name');
    end
        % set position of new inports
    unpackBlkPort = get_param(unpackBlk,'PortHandles');
    inport = find_system(unpackSysPath,'blockType','Inport');
    for i = 1:numOutput-1
        outputPos = get_param(unpackBlkPort{1}.Outport(i),'Position');
        set_param(convertCharsToStrings(inport(i)),'Position',...
            [outputPos(1)-430,outputPos(2)-7,outputPos(1)-400,outputPos(2)+7]);
    end
    % remove unpack block
        % save connections info for later
    opNameList = strings(1,size(upSigTable,1));
    lineNameList = strings(1,size(upSigTable,1));
    for i = 1:size(upSigTable,1)
       [name,~,~] = cntedBlockInfo(unpackBlk{1},'Outport',i);
       opNameList{i} = name;
       lineNameList{i} = lineInfo(unpackBlk{1},'Outport','name',i);
    end
        % remove unpack block
    removeLine(unpackBlk{1},'Outport','start','end');
    delete_block(unpackBlk{1});
    % connect new inports to datatype convert blocks
    for i = 1:size(upSigTable,1)
        add_line(unpackSysPath, convertCharsToStrings(get_param(inport(i),'Name'))+'/1',...
            convertCharsToStrings(opNameList{i})+'/1');
        setLineParam(inport{i},'Outport',1,'name',lineNameList{i});
    end
    % connect outter bus collector to rx system
    mailboxName = convertCharsToStrings(get_param(mailbox,'Name'));
    unpackSysName = convertCharsToStrings(get_param(unpackSysPath,'Name'));
    for i = 1:size(upSigTable,1)
        add_line(get_param(unpackSys,'Parent'),mailboxName+'/'+(i+1),unpackSysName+'/'+i);
    end
    newMsgDstName = convertCharsToStrings(get_param(newMsgDst,'Name'));
    add_line(get_param(unpackSys,'Parent'),mailboxName+'/1',newMsgDstName+'/1');
end

end

