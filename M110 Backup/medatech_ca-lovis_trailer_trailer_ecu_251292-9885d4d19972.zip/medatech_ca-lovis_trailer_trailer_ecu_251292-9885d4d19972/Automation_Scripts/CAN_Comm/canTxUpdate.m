function err_flag = canTxUpdate(error_log)
err_flag = false;
% J1939
J1939TxList = find_system(bdroot,'MaskType','TM4 J1939 CAN Pack');
for i = 1:size(J1939TxList,1)
    try
        replaceTxBlock(1,J1939TxList(i));
    catch ME
        err_flag = true;
        fprintf(error_log,'Error configuring J1939 tx block: ');
        fprintf(error_log,convertCharsToStrings(J1939TxList(i)));
        fprintf(error_log,'\n');
        fprintf(error_log, [ME.message,'\n']);
    end
end

% general CAN
canTxList = find_system(bdroot,'MaskType','TM4 CAN Pack');
for i = 1:size(canTxList,1)
    try
        replaceTxBlock(2,canTxList(i));
    catch ME
        err_flag = true;
        fprintf(error_log,'Error configuring CAN tx block: ');
        fprintf(error_log,convertCharsToStrings(canTxList(i)));
        fprintf(error_log,'\n');
        fprintf(error_log, [ME.message,'\n']);
    end
end
end

