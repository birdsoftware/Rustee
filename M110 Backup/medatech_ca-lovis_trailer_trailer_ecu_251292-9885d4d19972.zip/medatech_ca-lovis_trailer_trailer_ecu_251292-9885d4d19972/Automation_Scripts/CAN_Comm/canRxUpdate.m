function err_flag = canRxUpdate(error_log)
err_flag = false;
% J1939
J1939RxList = find_system(bdroot,'MaskType','TM4 J1939 CAN Unpack');
for i = 1:size(J1939RxList,1)
    try
        replaceRxJ1939(J1939RxList(i));
    catch ME
        err_flag = true;
        fprintf(error_log,'Error configuring J1939 rx block: ');
        fprintf(error_log,convertCharsToStrings(J1939RxList(i)));
        fprintf(error_log,'\n');
        fprintf(error_log, [ME.message,'\n']);
    end
end

% General CAN
canRxList = find_system(bdroot,'MaskType','TM4 Receive CAN Message');
for i = 1:size(canRxList,1)
    try
        replaceRxCAN(canRxList(i));
    catch ME
        err_flag = true;
        fprintf(error_log,'Error configuring CAN rx block: ');
        fprintf(error_log,convertCharsToStrings(canRxList(i)));
        fprintf(error_log,'\n');
        fprintf(error_log, [ME.message,'\n']);
    end
end
end

