function manualRxCAN()
%%% 
%%% Manually replace a single CAN Rx block %%%
%%%

unpackBlk = find_system(gcb,'MaskType','TM4 CAN Unpack');
unpackSys = get_param(unpackBlk,'Parent');

% obtain parameters from unpack block
upUserData = get_param(unpackBlk,'userData');
CanDbFile = upUserData{1,1}.CanDbFile;
MsgName = upUserData{1,1}.MsgName;
upSigTable = upUserData{1,1}.MsgSignalTable;
SigList = "";
for row_num = 1:size(upSigTable,1)
    SigList = SigList + ...
        convertCharsToStrings(upSigTable{row_num,1}(1:min(length(upSigTable{row_num,1}),32)));
    if row_num ~= size(upSigTable,1)
        SigList = SigList + ",";
    end
end

% save connection information
targetPortList = zeros(1,size(upSigTable,1));
lineNameList = strings(1,size(upSigTable,1));
for i = 1:size(upSigTable,1)
   targetPH = lineInfo(unpackBlk{1,1},'Outport','DstPortHandle',i);
   targetPortList(i) = targetPH;
   lineNameList{i} = lineInfo(unpackBlk{1},'Outport','name',i);
end
% remove unpack block
removeLine(unpackBlk{1},'Outport','start','end');

% replace tm4 block with oe block
replaceCAN(unpackBlk{1,1},'TM4 CAN Unpack', 'Medatech_Lib/OpenECU CAN Receive',...
                CanDbFile, MsgName, SigList);
            
% connect new inports to datatype convert blocks
oePortHandle = get_param(unpackBlk{1,1},'portHandles');
for i = 1:size(upSigTable,1)
    add_line(unpackSys, oePortHandle.Outport(i+1),targetPortList(i));
    setLineParam(unpackBlk{1,1},'Outport',i+1,'name',lineNameList{i});
end
            
end

