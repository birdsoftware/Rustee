function replaceRxJ1939(blockPath)
blockPath = blockPath{1};
% ------ get information from TM4 CAN unpack block
old_block = find_system(blockPath,'MaskType','TM4 J1939 CAN Unpack');
userData = get_param(old_block, 'UserData');
CanDbFile = userData{1,1}.CanDbFile;
MsgName = userData{1,1}.MsgName;
SigTable = userData{1,1}.MsgSignalTable;
SigTableSize = size(SigTable);
SigList = "";
for row_num = 1:SigTableSize(1)
    SigList = SigList + convertCharsToStrings(SigTable{row_num,1});
    if row_num ~= SigTableSize(1)
        SigList = SigList + ",";
    end
end

% ------ Replace block with OpenECU block
% get list of original outport names
load_system('Medatech_Lib');
load_system(blockPath);

lh = get_param(blockPath,'lineHandles');
numOutport = length(lh.Outport);
dstPortList = ones(numOutport);
ph = get_param(blockPath,'portHandles');
portNameList = strings(numOutport,1);
for i = 1:numOutport
    dstPortList(i) = get_param(lh.Outport(i),'DstPortHandle');
    portNameList(i) = get_param(ph.Outport(i),'Name');
    delete_line(lh.Outport(i));
end
% replace  TM4 block with OpenECU block
originPos = get_param(blockPath,'Position');
replace_block(blockPath,'TM4 J1939 CAN Unpack', 'Medatech_Lib/OpenECU CAN Receive','noprompt');
set_param(blockPath,'candb_file',CanDbFile);
set_param(blockPath,'msg_name',MsgName);
set_param(blockPath,'signal_name',SigList);
set_param(blockPath,'Position',originPos);
% reconnect new OpenECU block to outports
dividers = strfind(blockPath,'/');
lastDivider = dividers(length(dividers));
currentSys = blockPath(1:lastDivider);
currentPH = get_param(blockPath,'portHandles');
for i = 1:numOutport
     add_line(currentSys,currentPH.Outport(i), dstPortList(i));
     set_param(currentPH.Outport(i),'Name',portNameList{i});
end

end

