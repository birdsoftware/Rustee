% oldBlockList = find_system(gcs,'MaskType','OpenECU Write Item');
% result_table = string(length(oldBlockList));
% for item = 1:length(oldBlockList)
%    value = get_param(oldBlockList{item},'dd_variable');
%    value = value(3:length(value));
%    result_table(item,1) = value;
% end

toBeDeleted = zeros(height(writeItem_table));
for row = 1:height(writeItem_table)
    if ~any(contains(result_table,writeItem_table{row,2}))
        toBeDeleted(row) = row;
    end
end

writeItem_table(nonzeros(toBeDeleted),:) = [];

% writeItemList = find_system(gcs,'MaskType','TM4 Write Item');
% for i = 1:length(writeItemList)
%     itemName = get_param(writeItemList{i},'ItemName');
%     replace_block(writeItemList{i},'TM4 Write Item','Medatech_Lib/OpenECU Write Item','noprompt');
%     set_param(writeItemList{i},'dd_variable',itemName);
% end
% 
% %%% Replace TM4 Write Items blocks with OPENECU write item blocks
% load_system('Medatech_Lib'); % load custom library
% load_system(gcs);
% %get the list of path of all block to be replaced
% oldBlockList = find_system(gcs,'MaskType','TM4 Write Item');
% %loop through all items to be replaced
% for item = 1:length(oldBlockList)
%     %get reference object name
%     ddName = get_param(oldBlockList{item},'ItemName'); % get reference variable name
%     showOp = get_param(oldBlockList{item},'ShowOutput');   % get number of outport
%     input_enum = get_param(oldBlockList{item},'InputEnumType');
%     output_enum = get_param(oldBlockList{item},'OutputEnumType');
%     %replace the old block with new block referencing to object name
%     currentPath = oldBlockList{item};   % path to the current block
%     try
%         replace_block(currentPath,'TM4 Write Item','Medatech_Lib/OpenECU Write Item','noprompt');  % replace TM4 block with OpenECU block
%         set_param(gcb,'dd_variable',['m_' ddName]);  % set new block value to corresponding dd value
%         set_param(gcb,'showop',showOp);
%         set_param(gcb,'input_enum',input_enum);
%         set_param(gcb,'output_enum',output_enum);
%     catch ME
%         log error
%         disp(oldBlockList{item});
%     end
% end