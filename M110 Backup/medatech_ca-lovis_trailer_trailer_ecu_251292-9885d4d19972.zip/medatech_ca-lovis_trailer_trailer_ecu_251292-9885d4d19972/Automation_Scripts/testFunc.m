function result = testFunc(originalStr)
sig_str = strsplit(originalStr,',');
rev_str = "";
for i = 1:length(sig_str)
    rev_str = rev_str +  convertCharsToStrings(sig_str(length(sig_str)+1-i));
    if i ~= length(sig_str)
        rev_str = rev_str + ",";
    end
end

result = rev_str;
end

