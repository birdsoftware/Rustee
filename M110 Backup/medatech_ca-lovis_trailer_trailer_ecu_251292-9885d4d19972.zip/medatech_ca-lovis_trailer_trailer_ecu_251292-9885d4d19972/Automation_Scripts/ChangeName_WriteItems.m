oldBlockList = find_system(gcs,'MaskType','OpenECU Write Item');%click page
for item = 1:length(oldBlockList)
   value = get_param(oldBlockList{item},'dd_variable');
   valueSplit = strsplit(value,'_');
   valueSplit{2} = [valueSplit{2} 'EDN'];% charcter inserted after 2 '_'
   result_value = '';
   for i = 1:length(valueSplit)
       result_value = strcat(result_value,valueSplit(i));
       if i<length(valueSplit)
           result_value = strcat(result_value,'_');
       end
   end
   
   set_param(oldBlockList{item},'dd_variable',result_value{1});
end