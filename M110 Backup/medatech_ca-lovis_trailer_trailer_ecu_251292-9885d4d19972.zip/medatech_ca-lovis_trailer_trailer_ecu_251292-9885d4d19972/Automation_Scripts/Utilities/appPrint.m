function appPrint(field,text)
% print to app
if isempty(field.Value) 
    field.Value = text;
else
    field.Value = [field.Value;text]; 
end
% print to command window
fprintf(convertCharsToStrings(text)+'\n'); 
pause(0.1);
end

