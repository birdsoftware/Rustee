function removeLine(blockPath,type,from,to)
%{
Delete input/output lines of the current block. Remove only specified lines by
setting 'from' and 'to'. Set 'from' = "start" to start from the first line, 'to'
= "end" to end at the last line.
%}
lineHandles = get_param(blockPath,'LineHandles');
if class(from)=="char" && from=="start"
   from = 1; 
end
if type=="Outport"
    if class(to)=="char" && to=="end"
        to = numel(lineHandles.Outport); 
    end
    for i = from:to
        if lineHandles.Outport(i)~=-1
            delete_line(lineHandles.Outport(i));
        end
    end
elseif type=="Inport"
     if class(to)=="char" && to=="end"
        to = numel(lineHandles.Inport); 
    end
    for i = from:to
        if lineHandles.Inport(i)~=-1
            delete_line(lineHandles.Inport(i));
        end
    end
end
end

