function setLineParam(blockPath,portType,num,param,value)
lh = get_param(blockPath,'lineHandles');
if portType=="Outport"
    set_param(lh.Outport(num),param,value);
elseif portType=="Inport"
    set_param(lh.Inport(num),param,value);
end
end

