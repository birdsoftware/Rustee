function result = lineInfo(blockPath,portType,param,num)
result = '';
lh = get_param(blockPath,'lineHandles');
if portType=="Outport"
    result = get_param(lh.Outport(num),param);
elseif portType=="Inport"
    result = get_param(lh.Inport(num),param);
end
end

