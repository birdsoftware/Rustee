function [name,type,path] = cntedBlockInfo(blockPath,portType,num)
%{
Return the name and type of the block that is connected to the currently
block @ port 'num'
%}

connectivity = get_param(blockPath,'PortConnectivity');
dstBlock = find(cellfun(@isempty,{connectivity.DstBlock})==0);
srcBlock = find(cellfun(@isempty,{connectivity.SrcBlock})==0);

if portType=="Outport"
    targetBlock = connectivity(dstBlock(num)).DstBlock;
elseif portType=="Inport"
    targetBlock = connectivity(srcBlock(num)).SrcBlock;
end

name = get_param(targetBlock,'Name');
path = convertCharsToStrings(get_param(targetBlock,'Parent'))+'/'+convertCharsToStrings(name);
type = get_param(targetBlock,'maskType');
if type == ""
    type = get_param(targetBlock,'blockType');
end
