%%%------------ CREATE DATA DICTIONARY FROM TM4 EEPROM EXPORT ------------- %%%
% parse txt and save as csv
% py_cmd = strcat('python'," ",scripts_path,'Python_Scripts\parse_staParam.py'," ",scripts_path);
% py_exet_st = system(py_cmd);

% read from parsed csv
staParam_table = readtable(strcat(scripts_path,'Python_Scripts\staParam_parsed.csv'));
staParam_table = convertEnum(staParam_table);

% create and get section of the staParam data dictionary
Simulink.data.dictionary.create(strcat(scripts_path, 'Data_Dict\staParamDict.sldd'));
staParamDictObj = Simulink.data.dictionary.open('staParamDict.sldd');
dDataSectObj = getSection(staParamDictObj,'Design Data');
% loop through all rows
for row_num = 1:height(staParam_table)
    % create new Simulink parameters
    newParam = Simulink.Parameter;
        % use enumeration class if value is enumeration
    if isempty(staParam_table.Enum_Name{row_num}) % if not enum
        newParam.DataType = staParam_table.Type{row_num};
        if staParam_table.Size_M(row_num)~=1 || staParam_table.Size_N(row_num)~=1
            newParam.Value = str2num(staParam_table.Default_Value{row_num}); %#ok<ST2NM>
        else
            newParam.Value = str2double(staParam_table.Default_Value{row_num});
        end
            % use data type min/max value if Min/Max value is NaN
        if isnan(staParam_table.Min(row_num)) && ~isnan(staParam_table.Max(row_num))
            if staParam_table.Type{row_num} == "single"
                newParam.Min = -3.4e38;
            else
                newParam.Min = -intmax(staParam_table.Type{row_num});
            end
            newParam.Max = staParam_table.Max(row_num);
        elseif isnan(staParam_table.Max(row_num)) && ~isnan(staParam_table.Min(row_num))
            if staParam_table.Type{row_num} == "single"
                newParam.Max = 3.4e38;
            else
                newParam.Max = intmax(staParam_table.Type{row_num});
            end
            newParam.Min = staParam_table.Min(row_num);
        elseif ~isnan(staParam_table.Max(row_num)) && ~isnan(staParam_table.Min(row_num))
            newParam.Max = staParam_table.Max(row_num);
            newParam.Min = staParam_table.Min(row_num);
        end
    else % if enum
        enum = split(staParam_table.Default_Value{row_num},'.');
        enum_class = enumeration(enum{1});
        newParam.DataType = ['Enum: ' enum{1}];
        newParam.Value = enum_class(enum{2}==enum_class);
    end
    newParam.Description = staParam_table.Description{row_num};
        % use empty value if unit is "-"
    if staParam_table.Units{row_num}~="-"
        newParam.Unit = staParam_table.Units{row_num};
    end
    % storage class
    newParam.StorageClass = "ConstVolatile";
    % write to data dictionary
    addEntry(dDataSectObj,staParam_table.Item_Name{row_num},newParam);
end
% save changes
saveChanges(staParamDictObj);
addDataSource(masterDictObj,'staParamDict.sldd');   % reference staParam to master DD
saveChanges(masterDictObj);

%%%------------ REPLACE EXISTING READ BLOCK WITH VALUE IN DATA DICTIONARY -------------%%%
load_system('Medatech_Lib') % load custom library
load_system(project_file)

% get all programtically writable blocks
writeBlocks = find_system(bdroot,'MaskType','TM4 Write Static Parameter');
writeParams = strings(length(writeBlocks),1);
for i = 1:length(writeBlocks)
   writeParams{i} = get_param(writeBlocks{i},'ParamName');
end
writeParams = unique(writeParams);

% get the list of path of all block to be replaced
oldBlockList = find_system(bdroot,'MaskType','TM4 Read Static Parameter');
% loop through all items to be replaced
for item = 1:length(oldBlockList)
    % get reference object name
    ddName = get_param(oldBlockList{item},'ParamName'); % get reference variable name
    sampleTime = get_param(oldBlockList{item},'sampleTime'); % get sample time
    % replace the old block with new block referencing to object name
    currentPath = oldBlockList{item};   % path to the current block
    try
        replace_block(currentPath,'TM4 Read Static Parameter','Medatech_Lib/OpenECU Read NVRAM','noprompt');  % replace TM4 block with OpenECU blcok
        if contains(ddName,writeParams)    % use pnv_array if requires programmatical writability, otherwise use constant
            set_param(currentPath,'OverrideUsingVariant','pnv_array');
        else
            set_param(currentPath,'OverrideUsingVariant','constant');
        end
        set_param(currentPath,'NVM_Table',ddName);  % set new block value to corresponding dd value
        set_param(currentPath,'sample_time',sampleTime); % set new block sample time to corresponding value
        
    catch ME
        % log error
        error_flag = true;
        fprintf(error_log, [ME.message,'\n']);
    end
end

%%------------ REPLACE EXISTING WRITE BLOCK WITH VALUE IN DATA DICTIONARY -------------%%%
% get the list of path of all block to be replaced
load_system(project_file);
oldBlockList = find_system(bdroot,'MaskType','TM4 Write Static Parameter');
% loop through all items to be replaced
for item = 1:length(oldBlockList)
    %get reference object name
    currentBlock = Simulink.Mask.get(oldBlockList{item});   % get current block object
    ddName = currentBlock.Parameters(1,1).Value; % get reference variable name
    %replace the old block with new block referencing to object name
    currentPath = oldBlockList{item};   % path to the current block
    try
        replace_block(currentPath,'TM4 Write Static Parameter','Medatech_Lib/OpenECU Write NVRAM','noprompt');  % replace TM4 block with OpenECU block
        set_param(currentPath,'NVM_Table',ddName);  % set new block value to corresponding dd value
    catch ME
        % log error
        error_flag = true;
        fprintf(error_log, [ME.message,'\n']);
    end
end

