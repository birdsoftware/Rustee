%%%------------ CREATE DATA DICTIONARY FROM TM4 EEPROM EXPORT ------------- %%%
% parse txt and save as csv
py_cmd = strcat('python'," ",scripts_path,'Python_Scripts\parse_dynParam.py'," ",scripts_path);
py_exet_st = system(py_cmd);

% read from parsed csv
dynParam_table = readtable(strcat(scripts_path,'Python_Scripts\dynParam_parsed.csv'));
dynParam_table = convertEnum(dynParam_table);

% create and get section of the dynParam data dictionary
Simulink.data.dictionary.create(strcat(scripts_path, 'Data_Dict\dynParamDict.sldd'));
dynParamDictObj = Simulink.data.dictionary.open('dynParamDict.sldd');
dDataSectObj = getSection(dynParamDictObj,'Design Data');
% loop through all rows
for row_num = 1:height(dynParam_table)
    % create new Simulink parameters
    newParam = Simulink.Parameter;
        % use enumeration class if value is enumeration
    if isnan(dynParam_table.Enum_Name(row_num)) % if not enum
        newParam.DataType = dynParam_table.Type{row_num};
        if staParam_table.Size_M(row_num)~=1 || dynParam_table.Size_N(row_num)~=1
            newParam.Value = str2num(dynParam_table.Default_Value{row_num}); %#ok<ST2NM>
        else
            newParam.Value = str2double(dynParam_table.Default_Value{row_num});
        end
    else % if enum
        enum = split(dynParam_table.Default_Value{row_num},'.');
        enum_class = enumeration(enum{1});
        newParam.DataType = ['Enum: ' enum{1}];
        newParam.Value = enum_class(enum{2}==enum_class);
    end
    
        % use empty value if unit is "-"
    if dynParam_table.Units{row_num}~="-"
        newParam.Unit = dynParam_table.Units{row_num};
    end
    % storage class
    newParam.StorageClass = "ConstVolatile";
    % write to data dictionary
    addEntry(dDataSectObj,dynParam_table.Item_Name{row_num},newParam);
end
% save changes
saveChanges(dynParamDictObj);
addDataSource(masterDictObj,'dynParamDict.sldd');   % reference dynParam to master DD
saveChanges(masterDictObj);

%%%------------ REPLACE EXISTING READ BLOCK WITH VALUE IN DATA DICTIONARY -------------%%%
load_system('Medatech_Lib') % load custom library
load_system(project_file)
% get the list of path of all block to be replaced
oldBlockList = find_system(gcs,'MaskType','TM4 Read Dynamic Parameter');
% loop through all items to be replaced
for item = 1:length(oldBlockList)
    % get reference object name
    ddName = get_param(oldBlockList{item},'ParamName'); % get reference variable name
    sampleTime = get_param(oldBlockList{item},'sampleTime'); % get sample time
    % replace the old block with new block referencing to object name
    currentPath = oldBlockList{item};   % path to the current block
    try
        replace_block(currentPath,'TM4 Read Dynamic Parameter','Medatech_Lib/OpenECU Read NVRAM','noprompt');  % replace TM4 block with OpenECU blcok
        set_param(gcb,'NVM_Table',ddName);  % set new block value to corresponding dd value
        set_param(gcb,'sample_time',sampleTime); % set new block sample time to corresponding value
    catch ME
        % log error
        error_flag = true;
        fprintf(error_log, [ME.message,'\n']);
    end
end

%%------------ REPLACE EXISTING WRITE BLOCK WITH VALUE IN DATA DICTIONARY -------------%%%
% get the list of path of all block to be replaced
load_system(project_file);
oldBlockList = find_system(gcs,'MaskType','TM4 Write Dynamic Parameter');
% loop through all items to be replaced
for item = 1:length(oldBlockList)
    %get reference object name
    currentBlock = Simulink.Mask.get(oldBlockList{item});   % get current block object
    ddName = currentBlock.Parameters(1,1).Value; % get reference variable name
    %replace the old block with new block referencing to object name
    currentPath = oldBlockList{item};   % path to the current block
    try
        replace_block(currentPath,'TM4 Write Dynamic Parameter','Medatech_Lib/OpenECU Write NVRAM','noprompt');  % replace TM4 block with OpenECU block
        set_param(gcb,'NVM_Table',ddName);  % set new block value to corresponding dd value
    catch ME
        % log error
        error_flag = true;
        fprintf(error_log, [ME.message,'\n']);
    end
end

