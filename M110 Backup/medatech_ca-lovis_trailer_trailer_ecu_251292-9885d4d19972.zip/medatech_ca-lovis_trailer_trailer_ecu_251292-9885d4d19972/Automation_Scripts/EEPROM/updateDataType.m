% dTypeDictObj = Simulink.data.dictionary.open('test_dd.sldd');
% dDataSectObj = getSection(dTypeDictObj,'Design Data');
dDataSectObj = getSection(masterDictObj,'Design Data');

BOOL = Simulink.AliasType;
BOOL.Description = 'Simulink type alias for a boolean.';
BOOL.DataScope = 'Auto';
BOOL.HeaderFile = 'psy.h';
BOOL.BaseType = 'boolean';

F32 = Simulink.AliasType;
F32.Description = 'Simulink type alias for a 32-bit floating point.';
F32.DataScope = 'Auto';
F32.HeaderFile = 'psy.h';
F32.BaseType = 'single';

FREAL = Simulink.AliasType;
FREAL.Description = ['Simulink type alias for a 64-bit floating point. ' ...
                     'May be represented as a 32-bit floating point on ' ...
                     'the target ECU.'];
FREAL.DataScope = 'Auto';
FREAL.HeaderFile = 'psy.h';
FREAL.BaseType = 'double';

INT = Simulink.AliasType;
INT.Description = ['Simulink type alias for a signed integer (natural w' ...
                   'idth of target ECU).'];
INT.DataScope = 'Auto';
INT.HeaderFile = 'psy.h';
INT.BaseType = 'int32';

S16 = Simulink.AliasType;
S16.Description = 'Simulink type alias for a 16-bit signed integer.';
S16.DataScope = 'Auto';
S16.HeaderFile = 'psy.h';
S16.BaseType = 'int16';

S32 = Simulink.AliasType;
S32.Description = 'Simulink type alias for a 32-bit signed integer.';
S32.DataScope = 'Auto';
S32.HeaderFile = 'psy.h';
S32.BaseType = 'int32';

S8 = Simulink.AliasType;
S8.Description = 'Simulink type alias for a 8-bit signed integer.';
S8.DataScope = 'Auto';
S8.HeaderFile = 'psy.h';
S8.BaseType = 'int8';

U16 = Simulink.AliasType;
U16.Description = 'Simulink type alias for a 16-bit unsigned integer.';
U16.DataScope = 'Auto';
U16.HeaderFile = 'psy.h';
U16.BaseType = 'uint16';

U32 = Simulink.AliasType;
U32.Description = 'Simulink type alias for a 32-bit unsigned integer.';
U32.DataScope = 'Auto';
U32.HeaderFile = 'psy.h';
U32.BaseType = 'uint32';

U8 = Simulink.AliasType;
U8.Description = 'Simulink type alias for a 8-bit unsigned integer.';
U8.DataScope = 'Auto';
U8.HeaderFile = 'psy.h';
U8.BaseType = 'uint8';

UINT = Simulink.AliasType;
UINT.Description = ['Simulink type alias for an unsigned integer (natur' ...
                    'al width of target ECU).'];
UINT.DataScope = 'Auto';
UINT.HeaderFile = 'psy.h';
UINT.BaseType = 'uint32';

dType_list = [BOOL, FREAL, F32, S32, S16, S8, U32, U16, U8, INT, UINT];
dType_name_list = {'BOOL', 'FREAL', 'F32', 'S32', 'S16', 'S8', 'U32', 'U16', 'U8', 'INT', 'UINT'};
for dtype = 1:length(dType_list)
    addEntry(dDataSectObj,dType_name_list{dtype},dType_list(dtype));
end