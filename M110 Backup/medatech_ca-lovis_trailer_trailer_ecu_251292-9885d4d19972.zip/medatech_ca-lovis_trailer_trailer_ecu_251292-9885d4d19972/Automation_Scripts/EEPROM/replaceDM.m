function replaceDM(blockPath)
    
spn = get_param(blockPath,'EventIdList');
spn = num2str(hex2dec(spn(3:6)));
fmi = get_param(blockPath,'fmi');
lamp_malfcn = get_param(blockPath,'milLamp');
lamp_red = get_param(blockPath,'rsLamp');
lamp_amber = get_param(blockPath,'awLamp');
lamp_protect = get_param(blockPath,'pLamp');
position = get_param(blockPath,'position');

replace_block(blockPath,'J1939 SysFile Event With DM1 and DM2', 'Medatech_Lib/OpenECU Set DTC','noprompt');

set_param(blockPath,'Orientation','right');
set_param(blockPath,'dtc_table','DM1Data');
set_param(blockPath,'spn',spn);
set_param(blockPath,'fmi',fmi);
set_param(blockPath,'lamp_malfunction',lamp_malfcn);
set_param(blockPath,'lamp_red',lamp_red);
set_param(blockPath,'lamp_amber',lamp_amber);
set_param(blockPath,'lamp_protect',lamp_protect);
set_param(blockPath,'position',position);
set_param(blockPath,'showname','off');

end

