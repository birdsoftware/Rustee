generator_crit_temp=95;
rectifier_crit_temp=95;
enclosure_crit_temp=85;
tanker_crit_p=23;
tanker_crit_v=-9.82;
external_crit_p=23;
external_crit_v=-9.82;
