error_data=readtable("error code map.xlsx",'ReadRowNames',true);

green_Pulses = error_data.greenPulses;
red_Pulses=error_data.redPulses;

