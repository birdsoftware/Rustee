dictionaryFile = 'sta_params_dict.sldd'; % existing sldd
dictionaryObj = Simulink.data.dictionary.open(dictionaryFile); % open existing
dDataSectObj = getSection(dictionaryObj, 'Design Data'); % open existing data section
foundEntries = find(dDataSectObj); % find entries in existing data section
for i = 1:length(foundEntries)
    foundEntry = getEntry(dDataSectObj, foundEntries(i).Name); % iterate through each entry in data secion
    %% Remap old value to new value (Simulink.Parameter to oe.Parameter Values)
    oldVal = getValue(foundEntry);
    newVal = oe.Parameter;
    newVal.Value = oldVal.Value;
    newVal.Description = oldVal.Description;
    newVal.DataType = oldVal.DataType;
    newVal.Max = oldVal.Max;
    newVal.Min = oldVal.Min;
    newVal.Unit = oldVal.Unit;
    newVal.Dimensions = oldVal.Dimensions;
    newVal.CoderInfo.StorageClass = 'Custom';
    newVal.CoderInfo.CustomStorageClass = 'Global';
    newVal.CoderInfo.CustomAttributes.MemorySection = 'Calibration';
    newVal.CoderInfo.CustomAttributes.HeaderFile = 'StaticParameters.h';
    newVal.CoderInfo.CustomAttributes.DefinitionFile = 'StaticParameters.c';
    %% Create new sldd with oe.Parameter entries
    newDictObj = Simulink.data.dictionary.open('StaticParameters.sldd');
    newSectObj = getSection(newDictObj, 'Design Data');
    addEntry(newSectObj, foundEntry.Name, newVal);
end