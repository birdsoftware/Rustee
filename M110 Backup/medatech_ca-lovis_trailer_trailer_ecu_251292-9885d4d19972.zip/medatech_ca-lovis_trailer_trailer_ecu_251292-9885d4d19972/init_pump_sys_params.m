D_pipe=3; %in
flow_lpm=5000; %lpm
h=10; %m
vis=0.005; %m^2/s
rho=1000; %kg/m^3
g=9.81;
P_atm=101325;

flow_si=flow_lpm/60/1000;

D_pipe_si=D_pipe*0.0254;
A_pipe=pi*D_pipe_si^2/4;
v=flow_si/A_pipe;

P_vis=vis*v/D_pipe_si;

delta_P=(P_vis+rho*g*h+P_atm)*1.1/10E3;
