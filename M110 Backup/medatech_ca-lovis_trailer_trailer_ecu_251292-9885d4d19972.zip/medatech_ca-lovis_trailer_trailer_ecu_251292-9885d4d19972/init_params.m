sample_time_1ms = 0.001;
sample_time_2ms = 0.002;
sample_time_5ms = 0.005;
sample_time_10ms = 0.01;
sample_time_20ms=0.02;
sample_time_50ms=0.05;
sample_time_100ms = 0.100;